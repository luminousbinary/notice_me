# flake8: noqa: F401
from skopt.space import Categorical, Dimension, Integer, Real

from .decimalspace import SKDecimal
